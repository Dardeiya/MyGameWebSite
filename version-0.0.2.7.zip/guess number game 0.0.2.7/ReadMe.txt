---

Ru
Это БЕТА версия, может быть много ошибок!  
Приятной игры!

БЕТА-версия будет действительна до версии 5.0.0

После версии 5.1.0 БЕТА-версия станет недействительной (обновления поддерживаться не будут)

---

Eng
This is a BETA version, there may be a lot of bugs!  
Have a nice game!

The BETA version will be valid until version 5.0.0.

After version 5.1.0 the BETA version will become invalid (updates will not be supported)

---
