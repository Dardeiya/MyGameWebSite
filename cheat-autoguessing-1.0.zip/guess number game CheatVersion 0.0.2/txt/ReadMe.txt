---

This is a BETA version, there may be a lot of bugs!  
Have a nice game!

The BETA version will be valid until version 5.0.0.

After version 5.1.0 the BETA version will become invalid (updates will not be supported)

---
